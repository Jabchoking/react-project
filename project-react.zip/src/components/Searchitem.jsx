import React, { memo } from 'react';

const Searchitem = memo(() => {
    return (
        <div>
            
        </div>
    );
});

export default Searchitem;