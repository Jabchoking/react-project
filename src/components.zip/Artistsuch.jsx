import React, { memo } from 'react';

const Artistsuch = memo(() => {
    return (
        <div>
            
        </div>
    );
});

export default Artistsuch;